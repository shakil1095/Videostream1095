Repo Player (Android, minSdk 19 / Android 4.4+)

BUILD
1. Install Android Studio. File > Open > select this folder (RepoPlayer).
2. Let Gradle sync (it downloads Gradle 8.7 and the libraries).
3. Build > Build APK(s)  (or Run on a device/emulator).

USE
- Host a JSON file (see sample-repo.json) e.g. on GitHub (use the "raw" URL).
- In the app: Add repo > paste the JSON URL.
- Tap a repo > tap an item or series > video plays.

NOTE: This app ships with no video sources. You choose what to add and are
responsible for only adding content you have the right to watch.

ANDROID TV / REMOTE CONTROL
- The app appears in the Android TV launcher (LEANBACK_LAUNCHER) and works with a remote.
- Lists: Up/Down to move, OK to open. Hold OK on a repo to remove it.
- Player: OK shows controls / play-pause, Left/Right seeks 10s, Back exits.
- Typing a repo URL with a remote is slow. Tip: use a short URL, or the
  phone app "Android TV Remote Control" / Google TV app keyboard to type faster.
- Replace app/src/main/res/drawable/banner.xml with a 320x180 PNG banner for a nicer launcher tile.

BUILD APK WITHOUT ANDROID STUDIO (GitHub)
1. Create a free GitHub account and a new repository.
2. Upload ALL files of this folder (including the hidden .github folder).
3. Open the Actions tab > "Build APK" > wait for the green tick.
4. Open the finished run > Artifacts > download RepoPlayer-apk (zip containing app-debug.apk).
5. Copy app-debug.apk to your phone/TV and install (allow "unknown sources").
