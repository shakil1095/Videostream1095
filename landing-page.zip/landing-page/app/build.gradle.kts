plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.repoplayer"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.repoplayer"
        minSdk = 19            // Android 4.4
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // If you get a "too many methods" error, add: multiDexEnabled = true
        // and implementation("androidx.multidex:multidex:2.0.1")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions { jvmTarget = "1.8" }
}

dependencies {
    // ExoPlayer 2.19.x is the last line that still supports API < 21
    implementation("com.google.android.exoplayer:exoplayer-core:2.19.1")
    implementation("com.google.android.exoplayer:exoplayer-hls:2.19.1")
    implementation("com.google.android.exoplayer:exoplayer-dash:2.19.1")
    implementation("com.google.android.exoplayer:exoplayer-ui:2.19.1")
}
