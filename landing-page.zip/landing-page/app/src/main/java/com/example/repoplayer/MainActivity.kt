package com.example.repoplayer

import android.app.Activity
import android.app.AlertDialog
import android.app.UiModeManager
import android.content.Intent
import android.content.res.Configuration
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var title: TextView
    private lateinit var list: ListView
    private lateinit var addBtn: Button
    private var tv = false
    private val trail = ArrayList<Pair<String, List<Entry>>>() // empty = repo list screen

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tv = (getSystemService(UI_MODE_SERVICE) as UiModeManager).currentModeType ==
            Configuration.UI_MODE_TYPE_TELEVISION

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = dp(if (tv) 48 else 12) // bigger margin on TV (overscan)
            setPadding(p, p, p, p)
        }
        title = TextView(this).apply { textSize = if (tv) 28f else 20f; setPadding(0, 0, 0, dp(12)) }
        list = ListView(this).apply {
            // Clearly visible highlight for the item selected with the remote's arrow keys
            selector = ColorDrawable(0x663399FF)
            isDrawSelectorOnTop = false
            isFocusable = true
        }
        addBtn = Button(this).apply {
            text = "+ Add repo"
            textSize = if (tv) 22f else 16f
            isFocusable = true
            setOnClickListener { askRepo() }
        }
        root.addView(title)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(addBtn)
        setContentView(root)

        list.setOnItemClickListener { _, _, i, _ -> onPick(i) }
        list.setOnItemLongClickListener { _, _, i, _ ->
            if (trail.isEmpty()) { confirmRemove(i); true } else false
        }
        show()
    }

    private inner class Adapter(val items: List<String>) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(i: Int) = items[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View {
            val t = (v as? TextView) ?: TextView(this@MainActivity)
            t.text = items[i]
            t.textSize = if (tv) 24f else 18f
            val pad = dp(if (tv) 16 else 12)
            t.setPadding(pad, pad, pad, pad)
            return t
        }
    }

    private fun show() {
        val labels: List<String>
        if (trail.isEmpty()) {
            val repos = Store.load(this)
            title.text = if (repos.isEmpty()) "No repos yet - select Add repo"
            else if (tv) "My repos (hold OK on a repo to remove)" else "My repos (long-press to remove)"
            addBtn.visibility = View.VISIBLE
            labels = repos.map { it.name }
        } else {
            val (t, items) = trail.last()
            title.text = t
            addBtn.visibility = View.GONE
            labels = items.map { if (it.children.isNotEmpty()) "> ${it.title}" else it.title }
        }
        list.adapter = Adapter(labels)
        // Put the remote's focus on the list (or the Add button if the list is empty)
        list.post {
            if (list.count > 0) { list.requestFocus(); list.setSelection(0) }
            else addBtn.requestFocus()
        }
    }

    private fun onPick(i: Int) {
        if (trail.isEmpty()) {
            val r = Store.load(this)[i]
            load(r.url) { name, items -> trail.add(name to items); show() }
        } else {
            val e = trail.last().second[i]
            when {
                e.children.isNotEmpty() -> { trail.add(e.title to e.children); show() }
                e.url != null -> startActivity(
                    Intent(this, PlayerActivity::class.java).putExtra("url", e.url).putExtra("title", e.title)
                )
                else -> Toast.makeText(this, "No video URL for this item", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun load(url: String, done: (String, List<Entry>) -> Unit) {
        Toast.makeText(this, "Loading...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val (name, items) = Repo.parse(Net.get(url))
                runOnUiThread { done(name, items) }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun askRepo() {
        val input = EditText(this).apply { hint = "https://.../repo.json"; setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("Add repo URL")
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isNotEmpty()) load(url) { name, _ -> Store.add(this, RepoRef(name, url)); show() }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmRemove(i: Int) {
        val r = Store.load(this)[i]
        AlertDialog.Builder(this)
            .setTitle("Remove ${r.name}?")
            .setPositiveButton("Remove") { _, _ -> Store.remove(this, r.url); show() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onBackPressed() {
        if (trail.isNotEmpty()) { trail.removeAt(trail.size - 1); show() } else super.onBackPressed()
    }
}
