package com.example.repoplayer

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Tls.enable() // lets Android 4.1-4.4 talk TLS 1.2 (needed by most modern sites)
    }
}
