package com.example.repoplayer

import android.app.Activity
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.Toast
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.ui.PlayerView

/**
 * Remote control:
 *  OK/Enter  -> show controls / play-pause
 *  Left/Right -> seek back/forward (when controls are visible)
 *  Up/Down   -> move focus on the control bar
 *  Play/Pause/FF/RW media keys -> work too
 *  Back      -> exit player
 */
class PlayerActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var view: PlayerView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        view = PlayerView(this).apply {
            isFocusable = true
            isFocusableInTouchMode = true
            controllerShowTimeoutMs = 5000
        }
        setContentView(view)
        view.requestFocus()
    }

    // Let the player view handle remote keys first (ExoPlayer's recommended approach for TV)
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (view.dispatchKeyEvent(event)) return true
        return super.dispatchKeyEvent(event)
    }

    override fun onStart() {
        super.onStart()
        val p = ExoPlayer.Builder(this)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
        player = p
        view.player = p
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(this@PlayerActivity, "Playback error: ${error.errorCodeName}", Toast.LENGTH_LONG).show()
            }
        })
        p.setMediaItem(MediaItem.fromUri(intent.getStringExtra("url") ?: return))
        p.prepare()
        p.playWhenReady = true
    }

    override fun onStop() {
        super.onStop()
        view.player = null
        player?.release()
        player = null
    }
}
