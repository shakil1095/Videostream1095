package com.example.repoplayer

import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.Socket
import java.net.URL
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

data class Entry(val title: String, val url: String?, val children: List<Entry>)
data class RepoRef(val name: String, val url: String)

/**
 * A "repo" is just a JSON file hosted anywhere (GitHub raw, your own server...):
 * {
 *   "name": "My Repo",
 *   "items": [
 *     { "title": "Movie", "url": "https://.../video.m3u8" },
 *     { "title": "Series", "episodes": [ { "title": "Ep 1", "url": "https://.../1.mp4" } ] }
 *   ]
 * }
 * A plain top-level array of items also works.
 */
object Repo {
    fun parse(text: String): Pair<String, List<Entry>> {
        val t = text.trim()
        return if (t.startsWith("[")) "Repo" to entries(JSONArray(t))
        else {
            val o = JSONObject(t)
            o.optString("name", "Repo") to entries(o.getJSONArray("items"))
        }
    }

    private fun entries(a: JSONArray): List<Entry> = (0 until a.length()).map {
        val o = a.getJSONObject(it)
        Entry(
            o.optString("title", "Untitled"),
            o.optString("url", "").ifEmpty { null },
            o.optJSONArray("episodes")?.let { e -> entries(e) } ?: emptyList()
        )
    }
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("repos", Context.MODE_PRIVATE)

    fun load(c: Context): List<RepoRef> {
        val a = JSONArray(sp(c).getString("list", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            RepoRef(o.getString("name"), o.getString("url"))
        }
    }

    private fun save(c: Context, l: List<RepoRef>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("name", it.name).put("url", it.url)) }
        sp(c).edit().putString("list", a.toString()).apply()
    }

    fun add(c: Context, r: RepoRef) = save(c, load(c).filter { it.url != r.url } + r)
    fun remove(c: Context, url: String) = save(c, load(c).filter { it.url != url })
}

object Net {
    fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.instanceFollowRedirects = true
        return c.inputStream.bufferedReader().use { it.readText() }
    }
}

object Tls {
    fun enable() {
        if (Build.VERSION.SDK_INT !in 16..21) return
        try {
            val ctx = SSLContext.getInstance("TLSv1.2")
            ctx.init(null, null, null)
            HttpsURLConnection.setDefaultSSLSocketFactory(Tls12Factory(ctx.socketFactory))
        } catch (_: Exception) {
        }
    }
}

class Tls12Factory(private val d: SSLSocketFactory) : SSLSocketFactory() {
    private fun fix(s: Socket): Socket {
        if (s is SSLSocket) s.enabledProtocols = arrayOf("TLSv1.1", "TLSv1.2")
        return s
    }

    override fun getDefaultCipherSuites(): Array<String> = d.defaultCipherSuites
    override fun getSupportedCipherSuites(): Array<String> = d.supportedCipherSuites
    override fun createSocket(s: Socket, h: String, p: Int, a: Boolean) = fix(d.createSocket(s, h, p, a))
    override fun createSocket(h: String, p: Int) = fix(d.createSocket(h, p))
    override fun createSocket(h: String, p: Int, lh: InetAddress, lp: Int) = fix(d.createSocket(h, p, lh, lp))
    override fun createSocket(h: InetAddress, p: Int) = fix(d.createSocket(h, p))
    override fun createSocket(h: InetAddress, p: Int, a: InetAddress, lp: Int) = fix(d.createSocket(h, p, a, lp))
}
